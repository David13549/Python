# Ejercicio 3: Solicitar datos con input() directamente en el print, sin variables intermedias

print(
    f"Hola, Bienvenido {input('Ingresa tus Nombres: ')} {input('Ingresa tus Apellidos: ')} "
    f"gracias por registrarte a la materia de: {input('Ingresa la Materia: ')}, "
    f"tu usuario para ingresar es: {input('Ingresa tu Carnet: ')}@univo.edu.sv"
)