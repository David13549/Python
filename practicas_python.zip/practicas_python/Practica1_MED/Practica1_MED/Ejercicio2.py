# Ejercicio 2: Imprimir una tabla de datos con tabulaciones usando \t

# Encabezados de la tabla
print("Nombre\t\tApellido\tEdad\tCarrera")

# Primera fila de datos
print("Ana\t\tRamos\t\t19\tIngeniería de Software")

# Segunda fila de datos
print("Luis\t\tJiménez\t\t21\tIngeniería en Sistemas")

# Tercera fila de datos
print("Camila\t\tFlores\t\t20\tIngeniería de Datos")